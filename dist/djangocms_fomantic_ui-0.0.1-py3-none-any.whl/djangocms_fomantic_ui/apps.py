from django.apps import AppConfig


class PhiPluginsConfig(AppConfig):
    name = 'djangocms_fomantic_ui'

# djangocms-fomantic-ui

A collection of plug-ins bringing elements of the frontend
framework [Fomantic UI](https://fomantic-ui.com/), a fork of the
abandoned [Semantic UI](https://semantic-ui.com/), to Django CMS.

Stellaris_Clapper-board.svg taken from
[clker.com](http://www.clker.com/clipart-10793.html), public domain.